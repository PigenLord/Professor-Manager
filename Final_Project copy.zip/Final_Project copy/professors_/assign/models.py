from django.db import models
from django.utils import timezone
#one to many relationships
from django.contrib.auth.models import User

# Create your models here.
class Professor(models.Model): 
    name = models.CharField(max_length=100)
    profession = models.CharField(max_length=100)
    available = models.CharField(max_length=100)
    date_posted = models.DateTimeField(default=timezone.now)
    #if user is deleted post will be deleted as well 
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.name
