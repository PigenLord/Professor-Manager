from django.apps import AppConfig


class AssignConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assign'
