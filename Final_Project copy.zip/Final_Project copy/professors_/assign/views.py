from django.shortcuts import render
from .models import Professor

#Dictionary
posts = [
    {
        
        'name' : 'Edgardo Moya',
        'profession' : 'Computer Science Prof.',
        'available' : 'Full Time',
        'date_posted' : 'November 21, 2021',
        'author_id' : 'Admin123'
        
    },

    {
        
        'name' : 'Carlos Blooby',
        'profession' : 'History Prof.',
        'available' : 'Part Time',
        'date_posted' : 'November 21, 2021',
        'author_id' : 'Admin123'
        
    }
]

def home(request):
    context = {
        #post key, passing dictionary post
        #posts is a variable
        'posts': Professor.objects.all()
    }
    #uploading to the browser file home with dictionary context
    return render(request, 'assign/home.html', context)


def about(request):
    return render(request, 'assign/about.html', {'title': 'About'})